# Compression

Model compression using GPTQ. We're going to rely on the AutoGPTQ code base: https://github.com/PanQiWei/AutoGPTQ.
